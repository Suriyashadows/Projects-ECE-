# Networks
This repo contains very basic network routing, CRC, Stuffing and encryption schemes code snippets
It also has some code snippets related to digital signal processing (DSP) using Matlab. 
